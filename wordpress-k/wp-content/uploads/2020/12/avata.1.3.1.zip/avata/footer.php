<?php get_footer('frontpage');?>
<?php wp_footer(); ?>
</body>
</html>