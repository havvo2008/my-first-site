<?php

/**
 * Field overrides.
 */
class Hoo_Field_Dimension extends Hoo_Field {

	/**
	 * Sets the control type.
	 *
	 * @access protected
	 */
	protected function set_type() {

		$this->type = 'hoo-dimension';

	}
}
