<?php

/**
 * Default Section.
 */
class Hoo_Sections_Default_Section extends WP_Customize_Section {

	/**
	 * The section type.
	 *
	 * @access public
	 * @var string
	 */
	public $type = 'hoo-default';

}
