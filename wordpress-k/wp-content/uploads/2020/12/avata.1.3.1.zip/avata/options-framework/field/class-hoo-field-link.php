<?php

/**
 * Field overrides.
 */
class Hoo_Field_Link extends Hoo_Field_Hoo_URL {}
