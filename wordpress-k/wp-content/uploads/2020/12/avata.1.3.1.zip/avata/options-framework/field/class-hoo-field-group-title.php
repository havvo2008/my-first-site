<?php

/**
 * Prior to version 0.8 there was a separate 'group-title' field.
 * This exists here just for backwards-compatibility purposes.
 */
class Hoo_Field_Group_Title extends Hoo_Field_Custom {}
