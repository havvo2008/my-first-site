<?php

/**
 * This is nothing more than an alias for the Hoo_Field_Select class.
 * In older versions of Hoo there was a separate 'select2' field.
 * This exists here just for compatibility purposes.
 */
class Hoo_Field_Select2 extends Hoo_Field_Select {}
