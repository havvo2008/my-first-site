<?php

/**
 * Expanded Section.
 */
class Hoo_Sections_Expanded_Section extends WP_Customize_Section {

	/**
	 * The section type.
	 *
	 * @access public
	 * @var string
	 */
	public $type = 'hoo-expanded';

}
