<?php

/**
 * This is simply an alias for the Hoo_Field_Hoo_Generic class.
 */
class Hoo_Field_Generic extends Hoo_Field_Hoo_Generic {}
